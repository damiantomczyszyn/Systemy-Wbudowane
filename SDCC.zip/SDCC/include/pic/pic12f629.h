/*
 * Register Declarations for Microchip 12F629 Processor
 */
#include "pic12f675.h"

