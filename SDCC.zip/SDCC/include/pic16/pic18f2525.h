/*
 * pic18f2525.h - Device Library Header
 */

#include "pic18f4620.h"

