/* 
 * pic18f4431.h - device specific declarations
 */

#include "pic18f4331.h"

