/*
 * pic18f4480.h - Device Library Header
 */

#include "pic18f4580.h"

