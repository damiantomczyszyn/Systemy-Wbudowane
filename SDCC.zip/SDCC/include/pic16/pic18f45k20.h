/*
 * pic18f45k20.h - device specific declarations
 */

#include "pic18f46k20.h"

