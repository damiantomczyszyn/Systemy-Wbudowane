/*
 * pic18f2450.h - device specific declarations
 */

#include "pic18f4450.h"

