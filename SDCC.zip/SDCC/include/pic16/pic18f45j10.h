/* 
 * pic18f45j10.h - device specific declarations
 */

#include "pic18f44j10.h"

