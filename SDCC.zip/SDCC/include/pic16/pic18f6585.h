/*
 * pic18f6585.h - Device Library Header
 */

#include "pic18f8680.h"

