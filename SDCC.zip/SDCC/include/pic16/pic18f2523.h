/*
 * pic18f2523.h - device specific declarations
 */

#include "pic18f4523.h"

