/*
 * pic18f4515.h - device specific declarations
 */

#include "pic18f4610.h"

