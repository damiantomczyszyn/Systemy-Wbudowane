/*
 * pic18f2410.h - device specific declarations
 */

#include "pic18f4610.h"

