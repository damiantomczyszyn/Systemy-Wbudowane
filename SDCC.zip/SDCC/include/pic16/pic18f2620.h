/* 
 * pic18f2620.h - PIC18F2620 Device Library Header
 */

#include "pic18f4620.h"

