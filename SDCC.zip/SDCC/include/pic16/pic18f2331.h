/* 
 * pic18f2331.h - device specific declarations
 */

#include "pic18f4331.h"

