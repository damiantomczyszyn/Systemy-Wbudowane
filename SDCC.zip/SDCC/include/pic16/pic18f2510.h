/*
 * pic18f2510.h - device specific declarations
 */

#include "pic18f4610.h"

