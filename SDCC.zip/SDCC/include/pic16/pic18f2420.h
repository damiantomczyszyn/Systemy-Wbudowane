/* 
 * pic18f2420.h - PIC18F2420 Device Library Header
 */

#include "pic18f4520.h"

