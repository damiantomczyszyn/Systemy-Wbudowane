/* 
 * pic18f25j10.h - device specific declarations
 */

#include "pic18f24j10.h"

