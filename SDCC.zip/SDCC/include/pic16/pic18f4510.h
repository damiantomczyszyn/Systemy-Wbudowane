/*
 * pic18f4510.h - device specific declarations
 */

#include "pic18f4610.h"

