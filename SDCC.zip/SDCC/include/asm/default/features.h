/** default features.
 */
#ifndef __SDC51_ASM_FEATURES_H
#define __SDC51_ASM_FEATURES_H   1

#define _REENTRANT	__reentrant
#define _CODE		__code
#define _AUTOMEM
#define _STATMEM

#endif
